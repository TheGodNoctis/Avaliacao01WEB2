import React from 'react';

const Contato = () => {
  return <div>Página Fale Conosco</div>;
};

export default Contato;