const initialState = {
    categories: [], // Defina a estrutura do seu estado Redux aqui
  };
  
  const categoryReducer = (state = initialState, action) => {
    switch (action.type) {
      case 'FILTER_ITEMS':
        // Faça a lógica de filtragem aqui e atualize o estado conforme necessário
        return {
          ...state,
          // Atualize o estado com base na categoria recebida
          // Por exemplo, definindo a categoria ativa
          activeCategory: action.payload,
        };
      default:
        return state;
    }
  };
  
  export default categoryReducer;
  