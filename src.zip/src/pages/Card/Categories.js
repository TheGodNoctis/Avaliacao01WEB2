import React from 'react';
import { connect } from 'react-redux';
import { filterItems } from '../redux/actions'; 

const Categories = ({ categories, activeCategory, filterItems }) => {
  return (
    <div className="btn-container">
      {categories.map((category, index) => {
        return (
          <button
            type="button"
            className={`filter-btn ${category === activeCategory ? 'active' : ''}`}
            key={index}
            onClick={() => filterItems(category)}
          >
            {category}
          </button>
        )
      })}
    </div>
  )
}

// Mapeie o estado do Redux para as props do componente
const mapStateToProps = (state) => ({
  categories: state.categories,
  activeCategory: state.activeCategory, 
});

// Mapeie as ações do Redux para as props do componente
const mapDispatchToProps = {
  filterItems,
};

// Conecte o componente ao Redux
export default connect(mapStateToProps, mapDispatchToProps)(Categories);