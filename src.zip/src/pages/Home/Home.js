import React from 'react';
import Carousel from '../Menu/Carousel';

const Home = () => {
  return (
    <div>
      <Carousel />
    </div>
  );
};

export default Home;