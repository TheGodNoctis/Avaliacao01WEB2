export const signIn = (email, password) => async (dispatch) => {
    try {
      // Lógica para realizar o login
      // Se o login for bem-sucedido, você pode despachar a ação 'SIGN_IN' com os dados do usuário
      const user = await authAPI.signIn(email, password);
      dispatch({ type: 'SIGN_IN', payload: user });
    } catch (error) {
      // Em caso de erro no login, você pode despachar a ação 'SIGN_IN_ERROR' com a mensagem de erro
      dispatch({ type: 'SIGN_IN_ERROR', payload: error.message });
    }
  };
  