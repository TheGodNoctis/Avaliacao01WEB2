export const incrementarCliente = () => {
    return {
      type: 'INCREMENTAR_CLIENTE',
    };
  };
  